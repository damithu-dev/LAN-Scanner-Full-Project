"""Unit tests for Phase 7: Web Dashboard.

Validates:
1. Dashboard state initialization and session management.
2. In-memory data export formatting for Streamlit download buttons.
3. Execution scanning wrapper with mocked network engines.
"""

from unittest.mock import MagicMock, patch
import pytest

from dashboard.app import initialize_session_state
from scanner.models import Host, PortResult


def test_dashboard_imports_and_components():
    """Verify all dashboard subcomponents import cleanly without syntax or import errors."""
    import dashboard.app as app
    assert hasattr(app, "render_dashboard")
    assert hasattr(app, "execute_scan")
    assert hasattr(app, "render_sidebar")


def test_session_state_initialization():
    """Verify session state defaults are populated when keys are absent."""
    with patch("streamlit.session_state", {}) as mock_state:
        initialize_session_state()
        assert "scanned_hosts" in mock_state
        assert "is_scanning" in mock_state
        assert "last_scan_time" in mock_state
        assert "last_target" in mock_state


@patch("dashboard.app.arp_sweep")
@patch("dashboard.app.ConcurrentScanEngine")
def test_dashboard_execute_scan_flow(mock_engine_cls, mock_arp):
    """Verify execute_scan wires arguments to underlying scan engines."""
    import dashboard.app as app

    mock_arp.return_value = [Host(ip="192.168.1.10")]
    mock_engine = MagicMock()
    mock_engine_cls.return_value = mock_engine

    config = {
        "target": "192.168.1.0/24",
        "scan_mode": "TCP Connect (Standard 3-Way Handshake)",
        "port_selection": "Top 100 Common Ports",
        "custom_ports": "",
        "threads": 10,
        "timeout": 0.5,
        "max_pps": 0,
        "grab_banners": False,
        "allow_public": False,
    }

    mock_progress = MagicMock()
    mock_status = MagicMock()

    hosts = app.execute_scan(config, mock_progress, mock_status)
    assert len(hosts) == 1
    assert hosts[0].ip == "192.168.1.10"
    mock_engine.scan_host.assert_called_once()
