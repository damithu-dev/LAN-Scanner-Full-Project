"""Interactive Streamlit Web Dashboard for LAN Scanner & Active Port Scanner.

Provides real-time graphical controls for network discovery sweeps, active port
probes, service detection, interactive charts of open services and security risk
levels, report generation and downloads, and visible ethical safety policies.
"""

import io
import json
import os
import sys
import tempfile
import time
from typing import List, Optional

import pandas as pd
import streamlit as st

# Ensure parent directory is in Python path for intra-package imports
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from exporters.csv_exporter import export_csv
from exporters.html_exporter import export_html
from exporters.json_exporter import export_json
from exporters.xml_exporter import export_xml
from exporters.word_exporter import export_word_report
from scanner.banner import grab_banner
from scanner.concurrent_scan import ConcurrentScanEngine
from scanner.cve_lookup import get_cve_engine
from scanner.host_discovery import arp_sweep
from scanner.models import Host, PortResult
from scanner.port_probe import tcp_connect_probe
from scanner.stealth import tcp_syn_probe
from scanner.udp_probe import udp_probe
from utils.network import get_default_interface, get_local_ip, get_subnet_24, is_admin
from utils.ports import TOP_100_PORTS, TOP_1000_PORTS, parse_port_string
from utils.safety import AUTHORIZATION_NOTICE, RateLimiter, validate_target


def initialize_session_state() -> None:
    """Initialize persistent Streamlit session keys."""
    if "scanned_hosts" not in st.session_state:
        st.session_state["scanned_hosts"] = []
    if "is_scanning" not in st.session_state:
        st.session_state["is_scanning"] = False
    if "last_scan_time" not in st.session_state:
        st.session_state["last_scan_time"] = 0.0
    if "last_target" not in st.session_state:
        st.session_state["last_target"] = ""


def render_sidebar():
    """Render the configuration sidebar containing scan options and controls.

    Returns:
        dict: Parsed user configuration dictionary.
    """
    st.sidebar.title("🛡️ Scan Setup")
    st.sidebar.caption("Choose what to check. Hover over ⓘ help icons for explanations.")

    default_subnet = get_subnet_24()
    target_input = st.sidebar.text_input(
        "Device or network to check",
        value=default_subnet,
        help="Enter one device IP (for example, 127.0.0.1) or a network range (for example, 192.168.1.0/24). Only scan systems you own or have permission to test.",
    )

    scan_mode = st.sidebar.selectbox(
        "How should it check?",
        [
            "TCP Connect (Standard 3-Way Handshake)",
            "TCP SYN Stealth (Half-Open)",
            "UDP Scan (Service Payloads + ICMP)",
            "ARP Host Discovery Sweep Only",
        ],
        index=0,
        help="TCP Connect is a standard, straightforward check. SYN uses a half-open TCP probe and may require elevated permissions. UDP checks selected UDP services. ARP discovers local-network devices without checking their ports.",
    )

    port_selection = st.sidebar.radio(
        "Port Selection",
        ["Top 100 Common Ports", "Top 1000 Ports", "Custom Range / List"],
        index=0,
        help="More ports take longer to check. Start with the top 100 common ports or choose a small custom list for a quick demonstration.",
    )

    custom_ports_str = ""
    if port_selection == "Custom Range / List":
        custom_ports_str = st.sidebar.text_input(
            "Custom Ports",
            value="21,22,80,443,8080",
            help="E.g., 80,443 or 1-1024 or 80,8080-8090",
        )

    st.sidebar.markdown("---")
    st.sidebar.subheader("⚙️ Performance & Safety")

    threads = st.sidebar.slider("Concurrent Worker Threads", min_value=5, max_value=200, value=50, step=5)
    timeout = st.sidebar.slider("Socket Timeout (seconds)", min_value=0.2, max_value=3.0, value=1.0, step=0.1)
    max_pps = st.sidebar.slider("Rate Limit (Max Packets/Sec)", min_value=0, max_value=500, value=0, step=25, help="0 = unthrottled pacing")

    grab_banners_option = st.sidebar.checkbox("Grab Service Banners & CVE Hints", value=True)
    allow_public_option = st.sidebar.checkbox("Allow Public IP Scanning", value=False, help="Explicit override for external testing.")

    return {
        "target": target_input,
        "scan_mode": scan_mode,
        "port_selection": port_selection,
        "custom_ports": custom_ports_str,
        "threads": threads,
        "timeout": timeout,
        "max_pps": max_pps,
        "grab_banners": grab_banners_option,
        "allow_public": allow_public_option,
    }


def execute_scan(config: dict, progress_bar, status_text) -> List[Host]:
    """Execute network scan according to user sidebar parameters.

    Args:
        config (dict): Configuration options from sidebar.
        progress_bar: Streamlit progress widget.
        status_text: Streamlit text widget for status messaging.

    Returns:
        List[Host]: List of evaluated Host objects with results.
    """
    target = config["target"].strip()

    # Step 1: Safety verification
    is_safe, msg = validate_target(target, allow_public=config["allow_public"])
    if not is_safe:
        st.error(msg)
        return []

    if "WARNING" in msg:
        st.warning(msg)

    # Step 2: Resolve Target Ports
    if config["scan_mode"] == "ARP Host Discovery Sweep Only":
        target_ports = []
    elif config["port_selection"] == "Top 100 Common Ports":
        target_ports = TOP_100_PORTS
    elif config["port_selection"] == "Top 1000 Ports":
        target_ports = TOP_1000_PORTS
    else:
        try:
            target_ports = parse_port_string(config["custom_ports"])
        except ValueError as e:
            st.error(f"Port Specification Error: {e}")
            return []

    # Step 3: Discover Hosts
    status_text.text("🔍 Discovering active hosts on network...")
    if "/" in target or not target:
        hosts = arp_sweep(target or get_subnet_24(), timeout=config["timeout"])
        if not hosts:
            local_ip = get_local_ip()
            hosts = [Host(ip=local_ip, hostname="localhost")]
    else:
        hosts = [Host(ip=target)]

    if config["scan_mode"] == "ARP Host Discovery Sweep Only":
        progress_bar.progress(1.0)
        status_text.text("Host discovery complete.")
        return hosts

    # Step 4: Configure Probe Technique
    if "SYN" in config["scan_mode"]:
        probe_fn = tcp_syn_probe
    elif "UDP" in config["scan_mode"]:
        probe_fn = udp_probe
    else:
        probe_fn = tcp_connect_probe

    # Step 5: Execute Concurrent Port Probes
    rate_limiter = RateLimiter(max_pps=config["max_pps"]) if config["max_pps"] > 0 else None
    engine = ConcurrentScanEngine(
        max_threads=config["threads"],
        timeout=config["timeout"],
        rate_limiter=rate_limiter,
    )

    total_probes = max(1, len(hosts) * len(target_ports))
    completed = 0

    status_text.text(f"🚀 Scanning {len(target_ports)} ports across {len(hosts)} host(s)...")

    for host in hosts:
        def _cb(res: PortResult):
            nonlocal completed
            completed += 1
            progress_bar.progress(min(1.0, completed / total_probes))

        engine.scan_host(
            host=host,
            ports=target_ports,
            probe_fn=probe_fn,
            on_result=_cb,
        )

    # Step 6: Service Banners & CVE Lookup
    if config["grab_banners"]:
        status_text.text("📡 Extracting service banners and querying CVE database...")
        cve_engine = get_cve_engine()
        for host in hosts:
            for p in host.open_ports:
                if not p.banner:
                    banner, svc, _ = grab_banner(
                        ip=host.ip,
                        port=p.port,
                        timeout=min(1.5, config["timeout"]),
                        default_service=p.service,
                    )
                    p.banner = banner
                    if svc != "unknown":
                        p.service = svc
                cve_engine.annotate_port(p)

    progress_bar.progress(1.0)
    status_text.text("Scan completed successfully!")
    return hosts


def render_dashboard():
    """Main rendering routine for the dashboard UI."""
    st.set_page_config(
        page_title="LAN Scanner & Active Port Scanner",
        page_icon="🛡️",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    initialize_session_state()

    # Safety Notice Banner (Required Safety Rule)
    with st.expander("⚖️ Ethical & Legal Authorization Notice (Click to expand)", expanded=False):
        st.info(AUTHORIZATION_NOTICE)

    st.title("🌐 LAN Scanner & Active Port Scanner")
    st.caption("A guided network check for learning and authorized security reviews.")
    st.info("New here? Set the device or network in the left panel, keep the default settings for a first test, and select **Launch Scan**. Results appear below. An open port is not automatically a problem.")
    with st.expander("📘 Understand the results (plain-language guide)"):
        st.markdown("""- **Device found:** a device that responded to the scan.
- **Open port:** a network service appears to be listening; confirm it is expected.
- **Closed port:** the device responded, but no service accepted the connection on that port.
- **Filtered:** a firewall or network rule may have blocked the check.
- **Vulnerability hint:** a possible match based on service information, not proof of a vulnerability. Verify before taking action.
- **No findings:** this scan did not detect a matching issue; it does not guarantee the device is secure.""")

    # Environment Metrics Bar
    col_env1, col_env2, col_env3, col_env4 = st.columns(4)
    with col_env1:
        st.metric("Local IP", get_local_ip())
    with col_env2:
        st.metric("Primary Interface", get_default_interface() or "Auto")
    with col_env3:
        st.metric("/24 Local Subnet", get_subnet_24())
    with col_env4:
        admin_flag = is_admin()
        st.metric("Privilege Mode", "Administrator (Raw L2/L3)" if admin_flag else "User (TCP Connect)")

    st.markdown("---")

    # Sidebar inputs
    config = render_sidebar()

    # Trigger scan button
    if st.sidebar.button("▶️ Launch Scan", type="primary", use_container_width=True):
        progress_bar = st.progress(0.0)
        status_text = st.empty()

        start_time = time.time()
        scanned = execute_scan(config, progress_bar, status_text)
        elapsed = time.time() - start_time

        st.session_state.scanned_hosts = scanned
        st.session_state.last_scan_time = elapsed
        st.session_state.last_target = config["target"]

    hosts: List[Host] = st.session_state.scanned_hosts

    if not hosts:
        st.info("👈 Configure your scan parameters in the sidebar and click **'Launch Scan'** to begin auditing.")
        return

    # Top KPI Metrics Cards
    total_hosts = len(hosts)
    total_open_ports = sum(len(h.open_ports) for h in hosts)
    all_cves = [c for h in hosts for p in h.ports for c in p.cve_list]
    critical_cves = sum(1 for c in all_cves if c.get("severity") == "CRITICAL")

    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Hosts Discovered", total_hosts)
    m2.metric("Open Ports", total_open_ports)
    m3.metric("Security Alerts", len(all_cves), delta=f"{critical_cves} Critical" if critical_cves else None, delta_color="inverse")
    m4.metric("Scan Time", f"{st.session_state.last_scan_time:.2f}s")
    m5.metric("Target Scope", st.session_state.last_target or "Local")

    # Tabbed Views: Results Table, Charts, Vulnerability Insights, Exporters
    tab_table, tab_charts, tab_cves, tab_export = st.tabs([
        "📋 Discovered Hosts & Ports",
        "📊 Visual Analytics & Charts",
        "🚨 Vulnerability Hints",
        "💾 Export Reports",
    ])

    with tab_table:
        st.subheader("Discovered Network Endpoints")
        flattened_data = []
        for h in hosts:
            if not h.ports:
                flattened_data.append({
                    "IP Address": h.ip,
                    "MAC Address": h.mac or "N/A",
                    "Hardware Vendor": h.vendor,
                    "Port": "-",
                    "Protocol": "-",
                    "State": "UP (Host Active)",
                    "Service": "-",
                    "Banner / Version": "-",
                    "Risk Level": "INFORMATIONAL",
                })
            else:
                for p in h.ports:
                    risk = "INFORMATIONAL"
                    if p.cve_list:
                        severities = [c.get("severity", "MEDIUM") for c in p.cve_list]
                        risk = "CRITICAL" if "CRITICAL" in severities else ("HIGH" if "HIGH" in severities else "MEDIUM")
                    elif p.is_open:
                        risk = "LOW"

                    flattened_data.append({
                        "IP Address": h.ip,
                        "MAC Address": h.mac or "Local / Unknown",
                        "Hardware Vendor": h.vendor,
                        "Port": p.port,
                        "Protocol": p.protocol.upper(),
                        "State": p.state,
                        "Service": p.service,
                        "Banner / Version": p.banner or "-",
                        "Risk Level": risk,
                    })

        df = pd.DataFrame(flattened_data)
        st.dataframe(df, use_container_width=True)

    with tab_charts:
        st.subheader("Network Audit Analytics")
        c1, c2 = st.columns(2)

        with c1:
            st.markdown("##### Open Ports by Service")
            open_ports_list = [p for h in hosts for p in h.open_ports]
            if open_ports_list:
                service_counts = pd.Series([f"{p.service} ({p.port})" for p in open_ports_list]).value_counts().reset_index()
                service_counts.columns = ["Service & Port", "Count"]
                st.bar_chart(service_counts.set_index("Service & Port"))
            else:
                st.info("No open ports found to chart.")

        with c2:
            st.markdown("##### Security Risk Level Distribution")
            if flattened_data:
                risk_df = pd.DataFrame(flattened_data)["Risk Level"].value_counts().reset_index()
                risk_df.columns = ["Risk Level", "Count"]
                st.bar_chart(risk_df.set_index("Risk Level"))

    with tab_cves:
        st.subheader("Vulnerability Findings & Remediation Hints")
        st.caption("DISCLAIMER: Basic vulnerability hints only, based on banner heuristics. Not a full vulnerability scanner.")

        if all_cves:
            for cve in all_cves:
                severity = cve.get("severity", "MEDIUM")
                box_color = st.error if severity == "CRITICAL" else (st.warning if severity == "HIGH" else st.info)
                box_color(
                    f"**{cve.get('cve_id')} ({severity} - CVSS {cve.get('cvss')})**: {cve.get('title')}\n\n"
                    f"• **Description:** {cve.get('description')}\n\n"
                    f"• **Remediation:** {cve.get('fix')}"
                )
        else:
            st.success("✅ No known high-impact CVEs detected in the captured service banners.")

    with tab_export:
        st.subheader("Download Your Report")
        st.markdown("Choose a format below. **Word report** is recommended for non-technical readers because it explains what the results mean and suggests practical next steps. The other formats are better for spreadsheets or technical tools.")

        col_d1, col_d2, col_d3, col_d4, col_d5 = st.columns(5)

        # JSON Export in-memory
        with col_d1:
            json_str = io.StringIO()
            report_dict = {
                "generator": "LAN Scanner Dashboard",
                "target": st.session_state.last_target,
                "hosts": [h.to_dict() for h in hosts],
            }
            json_content = json.dumps(report_dict, indent=2)
            st.download_button(
                label="📥 Download JSON",
                data=json_content,
                file_name="lan_scan_report.json",
                mime="application/json",
                use_container_width=True,
            )

        # CSV Export in-memory
        with col_d2:
            csv_buffer = io.StringIO()
            import csv
            writer = csv.writer(csv_buffer)
            writer.writerow(["IP", "MAC", "Vendor", "Port", "Protocol", "State", "Service", "Banner", "CVEs"])
            for h in hosts:
                for p in h.ports:
                    cves = "; ".join(c.get("cve_id", "") for c in p.cve_list)
                    writer.writerow([h.ip, h.mac or "N/A", h.vendor, p.port, p.protocol, p.state, p.service, p.banner, cves])
            st.download_button(
                label="📥 Download CSV",
                data=csv_buffer.getvalue(),
                file_name="lan_scan_report.csv",
                mime="text/csv",
                use_container_width=True,
            )

        # XML Export in-memory
        with col_d3:
            with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as tf:
                xml_path = tf.name
            try:
                export_xml(hosts, xml_path, target=st.session_state.last_target, scan_time=st.session_state.last_scan_time)
                with open(xml_path, "r", encoding="utf-8") as f:
                    xml_content = f.read()
            finally:
                if os.path.exists(xml_path):
                    os.remove(xml_path)

            st.download_button(
                label="📥 Download XML (Nmap)",
                data=xml_content,
                file_name="lan_scan_report.xml",
                mime="application/xml",
                use_container_width=True,
            )

        # HTML Export in-memory
        with col_d4:
            with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as tf:
                html_path = tf.name
            try:
                export_html(hosts, html_path, target=st.session_state.last_target, scan_time=st.session_state.last_scan_time)
                with open(html_path, "r", encoding="utf-8") as f:
                    html_content = f.read()
            finally:
                if os.path.exists(html_path):
                    os.remove(html_path)

            st.download_button(
                label="📥 Download HTML Report",
                data=html_content,
                file_name="lan_scan_report.html",
                mime="text/html",
                use_container_width=True,
            )

        # Detailed Word report for non-technical readers
        with col_d5:
            word_path = None
            try:
                with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tf:
                    word_path = tf.name
                export_word_report(
                    hosts,
                    word_path,
                    target=st.session_state.last_target or "Not recorded",
                    scan_time=st.session_state.last_scan_time,
                    scan_mode=config["scan_mode"],
                    port_selection=config["port_selection"],
                )
                with open(word_path, "rb") as f:
                    word_content = f.read()
                st.download_button(
                    label="📄 Download Word Report",
                    data=word_content,
                    file_name="lan_scan_detailed_report.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    help="A detailed report with an executive summary, explanations of terms, device-by-device results, possible vulnerability hints, and recommended next steps.",
                    use_container_width=True,
                )
            finally:
                if word_path and os.path.exists(word_path):
                    os.remove(word_path)


if __name__ == "__main__":
    render_dashboard()
